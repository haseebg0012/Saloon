-- Run this in Supabase SQL Editor before using the booking form.

create table if not exists appointments (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  service text not null,
  barber text,
  appt_date date not null,
  appt_time time not null,
  notes text,
  created_at timestamptz default now()
);

alter table appointments enable row level security;

-- Allow anyone (anon key) to insert a booking from the website form.
create policy "Public can create appointments"
on appointments for insert
to anon
with check (true);

-- Reads are NOT open to anon by default — check bookings from the
-- Supabase Table Editor, or add an authenticated policy for an admin panel later.
