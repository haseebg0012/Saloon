// Edit everything in this file to rebrand the site — salon name, services,
// barbers, gallery, and contact info all live here so you don't have to
// touch component code.

export const SALON = {
  name: "Studio Noir",
  tagline: "Grooming, done with intent.",
  phone: "+92 300 1234567",
  whatsapp: "923001234567", // digits only, country code, no plus
  address: "Block 6, Main Boulevard, Karachi",
  timing: "Mon – Sat, 10:00 AM – 9:00 PM",
  instagram: "https://instagram.com",
};

export const SERVICES = [
  {
    id: "haircut",
    name: "Signature Haircut",
    short: "Precision cut, shaped to your face and finished with a hot towel.",
    price: "Rs. 1,500",
    duration: "45 min",
    image: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?q=80&w=1200&auto=format&fit=crop",
    detail: "A full consultation, wash, precision scissor and clipper work, then a hot towel finish. Built around your face shape and how you actually wear your hair day to day, not a one size fits all template.",
    includes: ["Consultation", "Wash & condition", "Scissor + clipper cut", "Hot towel finish", "Style & product"],
  },
  {
    id: "beard",
    name: "Beard Sculpt",
    short: "Line up, taper, and straight razor edging for a sharp finish.",
    price: "Rs. 900",
    duration: "30 min",
    image: "https://images.unsplash.com/photo-1621605815971-fbc98d665033?q=80&w=1200&auto=format&fit=crop",
    detail: "Full beard shaping with clippers and straight razor edging. We taper into the cheek and neck lines, condition the skin underneath, and finish with a cooling balm so there's no irritation.",
    includes: ["Beard trim & taper", "Straight razor edging", "Hot towel", "Balm finish"],
  },
  {
    id: "shave",
    name: "Classic Hot Shave",
    short: "Traditional straight razor shave with pre and post shave care.",
    price: "Rs. 1,200",
    duration: "40 min",
    image: "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?q=80&w=1200&auto=format&fit=crop",
    detail: "The old fashioned way. Hot towel prep, warm lather, a two pass straight razor shave, and a cold towel close with aftershave that won't sting. Built for a genuinely smooth finish.",
    includes: ["Hot towel prep", "Straight razor shave", "Cold towel close", "Aftershave balm"],
  },
  {
    id: "facial",
    name: "Gentleman's Facial",
    short: "Deep cleanse, scrub, and massage to reset tired skin.",
    price: "Rs. 2,000",
    duration: "50 min",
    image: "https://images.unsplash.com/photo-1519824145371-296894a0daa9?q=80&w=1200&auto=format&fit=crop",
    detail: "A deep cleanse, exfoliating scrub, and steam session followed by a facial massage and mask suited to your skin type. Meant to undo a few weeks of dust, sun, and stress in one sitting.",
    includes: ["Deep cleanse", "Steam & exfoliation", "Facial massage", "Mask & moisturizer"],
  },
  {
    id: "color",
    name: "Grey Blending",
    short: "Natural looking colour that softens grey without looking dyed.",
    price: "Rs. 2,500",
    duration: "60 min",
    image: "https://images.unsplash.com/photo-1560869713-7d0a29430803?q=80&w=1200&auto=format&fit=crop",
    detail: "A low ammonia colour process that blends grey into your natural tone gradually, so the result reads as your hair on a good week, not a fresh dye job. Includes a patch test on first visit.",
    includes: ["Consultation & patch test", "Colour application", "Processing", "Wash & finish"],
  },
  {
    id: "kids",
    name: "Junior Cut",
    short: "A relaxed haircut for kids under 12, done at their pace.",
    price: "Rs. 800",
    duration: "30 min",
    image: "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?q=80&w=1200&auto=format&fit=crop",
    detail: "A patient, no rush haircut for younger clients. We keep it simple, check in often, and make sure it's a good first experience with the chair, not just a fast trim.",
    includes: ["Consultation with parent", "Wash (optional)", "Cut & style"],
  },
];

export const BARBERS = [
  {
    id: "asad",
    name: "Asad Khan",
    role: "Senior Barber · 9 yrs",
    bio: "Known for sharp fades and beard sculpting.",
    image: "https://images.unsplash.com/photo-1618077360395-f3068be8e001?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "hamza",
    name: "Hamza Raza",
    role: "Barber · 5 yrs",
    bio: "Specialist in classic cuts and hot shaves.",
    image: "https://images.unsplash.com/photo-1633332755192-727a05c4013d?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "bilal",
    name: "Bilal Ahmed",
    role: "Colour Specialist · 6 yrs",
    bio: "Grey blending and creative colour work.",
    image: "https://images.unsplash.com/photo-1567894340315-735d7c361db0?q=80&w=800&auto=format&fit=crop",
  },
  {
    id: "usman",
    name: "Usman Tariq",
    role: "Junior Barber · 2 yrs",
    bio: "Great with kids and first time clients.",
    image: "https://images.unsplash.com/photo-1552058544-f2b08422138a?q=80&w=800&auto=format&fit=crop",
  },
];

export const GALLERY = [
  "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1622287162716-f311baa1a2b8?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?q=80&w=900&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?q=80&w=900&auto=format&fit=crop",
];
