import { useState, useEffect } from "react";
import { SERVICES } from "../data";

function ServiceCard({ service, onOpen, index }) {
  return (
    <div
      className="group rounded-2xl overflow-hidden border hairline flex flex-col"
      style={{ background: "var(--panel)" }}
    >
      <div className="relative h-56 overflow-hidden">
        <img
          src={service.image}
          alt={service.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
        />
        <span
          className="absolute top-4 left-4 font-mono text-xs px-2 py-1 rounded"
          style={{ background: "rgba(20,18,15,0.7)", color: "var(--brass)" }}
        >
          {String(index + 1).padStart(2, "0")}
        </span>
      </div>

      <div className="p-6 flex flex-col flex-1">
        <h3 className="font-display text-2xl mb-2" style={{ color: "var(--ivory)" }}>
          {service.name}
        </h3>
        <p className="text-sm leading-relaxed mb-5" style={{ color: "var(--stone)" }}>
          {service.short}
        </p>

        <div className="mt-auto">
          <div className="flex items-center justify-between border-t hairline pt-4 mb-4">
            <span className="font-mono text-xs uppercase tracking-wider" style={{ color: "var(--stone)" }}>
              {service.duration}
            </span>
            <span className="font-mono text-lg" style={{ color: "var(--brass)" }}>
              {service.price}
            </span>
          </div>
          <button
            onClick={() => onOpen(service)}
            className="w-full text-center py-2.5 rounded-full border hairline text-sm hover:border-[var(--brass)] hover:text-[var(--brass)] transition-colors"
          >
            See Details
          </button>
        </div>
      </div>
    </div>
  );
}

function ServiceModal({ service, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  if (!service) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8"
      style={{ background: "rgba(20,18,15,0.85)" }}
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={service.name}
    >
      <div
        className="max-w-2xl w-full rounded-2xl overflow-hidden border hairline max-h-[90vh] overflow-y-auto"
        style={{ background: "var(--panel)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative h-64 md:h-80">
          <img src={service.image} alt={service.name} className="w-full h-full object-cover" />
          <button
            onClick={onClose}
            aria-label="Close"
            className="absolute top-4 right-4 w-9 h-9 rounded-full flex items-center justify-center text-lg"
            style={{ background: "rgba(20,18,15,0.7)", color: "var(--ivory)" }}
          >
            ×
          </button>
        </div>

        <div className="p-7 md:p-9">
          <div className="flex items-start justify-between gap-4 mb-1">
            <h3 className="font-display text-3xl" style={{ color: "var(--ivory)" }}>
              {service.name}
            </h3>
            <span className="font-mono text-xl shrink-0" style={{ color: "var(--brass)" }}>
              {service.price}
            </span>
          </div>
          <p className="font-mono text-xs uppercase tracking-wider mb-6" style={{ color: "var(--stone)" }}>
            {service.duration}
          </p>

          <p className="text-sm leading-relaxed mb-6" style={{ color: "var(--ivory)" }}>
            {service.detail}
          </p>

          <p className="font-mono text-xs uppercase tracking-wider mb-3" style={{ color: "var(--brass)" }}>
            What's included
          </p>
          <ul className="space-y-2 mb-8">
            {service.includes.map((item) => (
              <li key={item} className="flex items-center gap-3 text-sm" style={{ color: "var(--ivory)" }}>
                <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: "var(--brass)" }} />
                {item}
              </li>
            ))}
          </ul>

          <a
            href="#booking"
            onClick={onClose}
            className="inline-block w-full text-center py-3 rounded-full font-medium text-sm"
            style={{ background: "var(--brass)", color: "var(--ink)" }}
          >
            Book This Service
          </a>
        </div>
      </div>
    </div>
  );
}

export default function Services() {
  const [active, setActive] = useState(null);

  return (
    <section id="services" className="px-6 md:px-14 py-24 md:py-32">
      <div className="max-w-3xl mb-14">
        <p className="font-mono text-xs tracking-[0.3em] uppercase mb-4" style={{ color: "var(--brass)" }}>
          Services
        </p>
        <h2 className="font-display text-4xl md:text-5xl leading-tight">
          Every service, priced plainly. No surprises at the chair.
        </h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {SERVICES.map((service, i) => (
          <ServiceCard key={service.id} service={service} index={i} onOpen={setActive} />
        ))}
      </div>

      <ServiceModal service={active} onClose={() => setActive(null)} />
    </section>
  );
}
