import { SALON } from "../data";

export default function Footer() {
  return (
    <footer className="px-6 md:px-14 py-14 border-t hairline">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div>
          <p className="font-display text-2xl mb-1">{SALON.name}</p>
          <p className="text-xs" style={{ color: "var(--stone)" }}>{SALON.address}</p>
        </div>
        <div className="flex flex-wrap gap-x-8 gap-y-2 font-mono text-xs" style={{ color: "var(--stone)" }}>
          <span>{SALON.timing}</span>
          <a href={`tel:${SALON.phone}`} className="hover:text-[var(--brass)] transition-colors">{SALON.phone}</a>
          <a href={SALON.instagram} className="hover:text-[var(--brass)] transition-colors">Instagram</a>
        </div>
      </div>
      <p className="mt-10 text-[11px] font-mono" style={{ color: "var(--stone)" }}>
        © {new Date().getFullYear()} {SALON.name}. All rights reserved.
      </p>
    </footer>
  );
}
