import { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { SERVICES, BARBERS, SALON } from "../data";

const initialForm = { name: "", phone: "", service: "", barber: "", date: "", time: "", notes: "" };

export default function Booking() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState("idle"); // idle | saving | done | error

  const update = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("saving");

    const { error } = await supabase.from("appointments").insert([
      {
        name: form.name,
        phone: form.phone,
        service: form.service,
        barber: form.barber || null,
        appt_date: form.date,
        appt_time: form.time,
        notes: form.notes || null,
      },
    ]);

    if (error) {
      console.error(error);
      setStatus("error");
      return;
    }

    setStatus("done");

    const waText = encodeURIComponent(
      `New appointment request\nName: ${form.name}\nPhone: ${form.phone}\nService: ${form.service}\nBarber: ${form.barber || "No preference"}\nDate: ${form.date}\nTime: ${form.time}`
    );
    window.open(`https://wa.me/${SALON.whatsapp}?text=${waText}`, "_blank");

    setForm(initialForm);
  };

  return (
    <section id="booking" className="px-6 md:px-14 py-24 md:py-32" style={{ background: "var(--panel)" }}>
      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12 items-start">
        <div>
          <p className="font-mono text-xs tracking-[0.3em] uppercase mb-4" style={{ color: "var(--brass)" }}>
            Book a Chair
          </p>
          <h2 className="font-display text-4xl md:text-5xl leading-tight mb-6">
            Reserve your time. We'll confirm on WhatsApp.
          </h2>
          <p className="text-sm leading-relaxed mb-8" style={{ color: "var(--stone)" }}>
            Fill in the details and submit — your request lands in our booking sheet, and we'll
            open WhatsApp so you can send it straight to the front desk for confirmation.
          </p>
          <div className="space-y-3 text-sm font-mono" style={{ color: "var(--ivory)" }}>
            <p>{SALON.timing}</p>
            <p>{SALON.phone}</p>
            <p style={{ color: "var(--stone)" }}>{SALON.address}</p>
          </div>
        </div>

        {/* the ledger */}
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl border hairline p-7 md:p-9 relative"
          style={{ background: "var(--ink)" }}
        >
          <span
            className="absolute -top-3 left-8 px-3 py-1 rounded-full font-mono text-[11px] uppercase tracking-wider"
            style={{ background: "var(--brass)", color: "var(--ink)" }}
          >
            Appointment Ledger
          </span>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field label="Full name" required>
              <input
                required
                value={form.name}
                onChange={update("name")}
                className="ledger-input"
                placeholder="Your name"
              />
            </Field>
            <Field label="Phone" required>
              <input
                required
                value={form.phone}
                onChange={update("phone")}
                className="ledger-input"
                placeholder="03xx xxxxxxx"
              />
            </Field>
          </div>

          <Field label="Service" required>
            <select required value={form.service} onChange={update("service")} className="ledger-input">
              <option value="" disabled>Choose a service</option>
              {SERVICES.map((s) => (
                <option key={s.id} value={s.name}>{s.name} — {s.price}</option>
              ))}
            </select>
          </Field>

          <Field label="Preferred barber">
            <select value={form.barber} onChange={update("barber")} className="ledger-input">
              <option value="">No preference</option>
              {BARBERS.map((b) => (
                <option key={b.id} value={b.name}>{b.name}</option>
              ))}
            </select>
          </Field>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field label="Date" required>
              <input
                required
                type="date"
                value={form.date}
                onChange={update("date")}
                className="ledger-input"
              />
            </Field>
            <Field label="Time" required>
              <input
                required
                type="time"
                value={form.time}
                onChange={update("time")}
                className="ledger-input"
              />
            </Field>
          </div>

          <Field label="Notes">
            <textarea
              value={form.notes}
              onChange={update("notes")}
              className="ledger-input resize-none"
              rows={2}
              placeholder="Anything we should know?"
            />
          </Field>

          <button
            type="submit"
            disabled={status === "saving"}
            className="w-full mt-4 py-3.5 rounded-full font-medium text-sm disabled:opacity-60"
            style={{ background: "var(--brass)", color: "var(--ink)" }}
          >
            {status === "saving" ? "Booking..." : "Confirm Appointment"}
          </button>

          {status === "done" && (
            <p className="mt-3 text-sm text-center" style={{ color: "var(--brass)" }}>
              Booked. Sending to WhatsApp for confirmation.
            </p>
          )}
          {status === "error" && (
            <p className="mt-3 text-sm text-center" style={{ color: "var(--wine)" }}>
              Something went wrong. Please try again or call us directly.
            </p>
          )}

          <style>{`
            .ledger-input{
              width: 100%;
              background: transparent;
              border: none;
              border-bottom: 1px solid var(--hairline);
              padding: 0.5rem 0.1rem;
              color: var(--ivory);
              font-size: 0.9rem;
            }
            .ledger-input:focus{ border-bottom-color: var(--brass); }
            select.ledger-input{ appearance: none; }
            select.ledger-input option{ background: var(--panel); color: var(--ivory); }
          `}</style>
        </form>
      </div>
    </section>
  );
}

function Field({ label, required, children }) {
  return (
    <label className="block mb-4">
      <span className="font-mono text-[10px] uppercase tracking-wider block mb-1" style={{ color: "var(--stone)" }}>
        {label}{required ? " *" : ""}
      </span>
      {children}
    </label>
  );
}
