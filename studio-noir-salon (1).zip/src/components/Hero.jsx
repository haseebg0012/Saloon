import { SALON } from "../data";

export default function Hero() {
  return (
    <header className="relative min-h-screen flex items-end overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1585747860715-2ba37e788b70?q=80&w=1800&auto=format&fit=crop')",
        }}
        aria-hidden="true"
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, rgba(20,18,15,0.55) 0%, rgba(20,18,15,0.75) 55%, var(--ink) 100%)",
        }}
        aria-hidden="true"
      />

      {/* top bar */}
      <nav className="absolute top-0 left-0 right-0 flex items-center justify-between px-6 md:px-14 py-6 z-10">
        <span className="font-display text-xl tracking-wide" style={{ color: "var(--ivory)" }}>
          {SALON.name}
        </span>
        <div className="hidden md:flex items-center gap-8 text-sm" style={{ color: "var(--stone)" }}>
          <a href="#services" className="hover:text-[var(--brass)] transition-colors">Services</a>
          <a href="#team" className="hover:text-[var(--brass)] transition-colors">Barbers</a>
          <a href="#gallery" className="hover:text-[var(--brass)] transition-colors">Gallery</a>
          <a
            href="#booking"
            className="border px-4 py-2 rounded-full hairline text-[var(--ivory)] hover:border-[var(--brass)] hover:text-[var(--brass)] transition-colors"
          >
            Book Appointment
          </a>
        </div>
      </nav>

      <div className="relative z-10 px-6 md:px-14 pb-20 md:pb-28 max-w-4xl rise-in">
        <p className="font-mono text-xs tracking-[0.3em] uppercase mb-5" style={{ color: "var(--brass)" }}>
          {SALON.address}
        </p>
        <h1
          className="font-display leading-[0.95] mb-6"
          style={{ fontSize: "clamp(2.75rem, 8vw, 6rem)", fontWeight: 400 }}
        >
          {SALON.tagline}
        </h1>
        <div className="flex flex-wrap items-center gap-4">
          <a
            href="#booking"
            className="inline-block px-7 py-3.5 rounded-full font-medium text-sm transition-transform hover:-translate-y-0.5"
            style={{ background: "var(--brass)", color: "var(--ink)" }}
          >
            Book an Appointment
          </a>
          <a
            href="#services"
            className="inline-block px-7 py-3.5 rounded-full border hairline text-sm hover:border-[var(--brass)] transition-colors"
          >
            View Services
          </a>
        </div>
      </div>
    </header>
  );
}
