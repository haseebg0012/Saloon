import { BARBERS } from "../data";

export default function Team() {
  return (
    <section id="team" className="px-6 md:px-14 py-24 md:py-32" style={{ background: "var(--panel)" }}>
      <div className="max-w-3xl mb-14">
        <p className="font-mono text-xs tracking-[0.3em] uppercase mb-4" style={{ color: "var(--brass)" }}>
          The Chair
        </p>
        <h2 className="font-display text-4xl md:text-5xl leading-tight">
          Meet the barbers you'll actually sit with.
        </h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
        {BARBERS.map((b) => (
          <div key={b.id} className="text-center">
            <div
              className="w-full aspect-square rounded-full overflow-hidden mb-4 border"
              style={{ borderColor: "var(--brass-dim)" }}
            >
              <img src={b.image} alt={b.name} className="w-full h-full object-cover" loading="lazy" />
            </div>
            <h3 className="font-display text-lg" style={{ color: "var(--ivory)" }}>
              {b.name}
            </h3>
            <p className="font-mono text-[11px] uppercase tracking-wider mt-1 mb-2" style={{ color: "var(--brass)" }}>
              {b.role}
            </p>
            <p className="text-xs leading-relaxed" style={{ color: "var(--stone)" }}>
              {b.bio}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
