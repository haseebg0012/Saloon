import { useState, useEffect } from "react";
import { GALLERY } from "../data";

export default function Gallery() {
  const [openIndex, setOpenIndex] = useState(null);

  useEffect(() => {
    const onKey = (e) => {
      if (openIndex === null) return;
      if (e.key === "Escape") setOpenIndex(null);
      if (e.key === "ArrowRight") setOpenIndex((i) => (i + 1) % GALLERY.length);
      if (e.key === "ArrowLeft") setOpenIndex((i) => (i - 1 + GALLERY.length) % GALLERY.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [openIndex]);

  return (
    <section id="gallery" className="px-6 md:px-14 py-24 md:py-32">
      <div className="max-w-3xl mb-14">
        <p className="font-mono text-xs tracking-[0.3em] uppercase mb-4" style={{ color: "var(--brass)" }}>
          Gallery
        </p>
        <h2 className="font-display text-4xl md:text-5xl leading-tight">
          A look inside the studio.
        </h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {GALLERY.map((src, i) => (
          <button
            key={src}
            onClick={() => setOpenIndex(i)}
            className={`overflow-hidden rounded-xl ${i % 5 === 0 ? "md:row-span-2" : ""}`}
            style={{ aspectRatio: i % 5 === 0 ? "3/4" : "4/3" }}
            aria-label={`Open image ${i + 1}`}
          >
            <img
              src={src}
              alt=""
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              loading="lazy"
            />
          </button>
        ))}
      </div>

      {openIndex !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "rgba(20,18,15,0.92)" }}
          onClick={() => setOpenIndex(null)}
          role="dialog"
          aria-modal="true"
        >
          <button
            onClick={() => setOpenIndex(null)}
            aria-label="Close"
            className="absolute top-6 right-6 w-9 h-9 rounded-full flex items-center justify-center text-lg"
            style={{ background: "rgba(255,255,255,0.1)", color: "var(--ivory)" }}
          >
            ×
          </button>
          <img
            src={GALLERY[openIndex]}
            alt=""
            className="max-h-[85vh] max-w-full rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </section>
  );
}
