import Hero from "./components/Hero";
import Services from "./components/Services";
import Team from "./components/Team";
import Gallery from "./components/Gallery";
import Booking from "./components/Booking";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div style={{ background: "var(--ink)" }}>
      <Hero />
      <Services />
      <Team />
      <Gallery />
      <Booking />
      <Footer />
    </div>
  );
}
